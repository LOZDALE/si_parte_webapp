<?php echo "Il server funziona!"; ?>
